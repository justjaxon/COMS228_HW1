package edu.iastate.cs228.hw1;

/**
 * Represents an outage cell in the town grid.
 */
public class Outage extends TownCell {

	/**
	 * Constructs an Outage object with references to the town, row, and column.
	 *
	 * @param p The town this cell belongs to.
	 * @param r The row index of this cell.
	 * @param c The column index of this cell.
	 */
	public Outage(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the State type of the cell, which is OUTAGE.
	 *
	 * @return State.OUTAGE
	 */
	@Override
	public State who() {
		return State.OUTAGE;
	}

	/**
	 * Determines the cell type in the next billing cycle based on the neighborhood
	 * census. The method always returns an Empty cell based on the outage rules.
	 *
	 * @param tNew The Town object for the next billing cycle.
	 * @return A new Empty cell object representing the cell's state in the next
	 *         cycle.
	 */
	@Override
	public TownCell next(Town tNew) {
		return new Empty(tNew, row, col);
	}
}
