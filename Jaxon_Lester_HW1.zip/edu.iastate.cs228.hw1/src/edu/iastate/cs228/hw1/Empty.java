package edu.iastate.cs228.hw1;

/**
 * Represents an empty cell in the town grid.
 */
public class Empty extends TownCell {

	/**
	 * Constructs an Empty object with references to the town, row, and column.
	 *
	 * @param p The town this cell belongs to.
	 * @param r The row index of this cell.
	 * @param c The column index of this cell.
	 */
	public Empty(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the State type of the cell, which is EMPTY.
	 *
	 * @return State.EMPTY
	 */
	@Override
	public State who() {
		return State.EMPTY;
	}

	/**
	 * Determines the cell type in the next billing cycle based on the neighborhood
	 * census. The method calculates the neighborhood census and chooses the next
	 * cell type accordingly.
	 *
	 * @param tNew The Town object for the next billing cycle.
	 * @return A new TownCell object representing the cell's state in the next
	 *         cycle.
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];

		census(nCensus);

		if (nCensus[OUTAGE] + nCensus[EMPTY] <= 1) {
			return new Reseller(tNew, row, col);
		}

		return new Casual(tNew, row, col);
	}
}