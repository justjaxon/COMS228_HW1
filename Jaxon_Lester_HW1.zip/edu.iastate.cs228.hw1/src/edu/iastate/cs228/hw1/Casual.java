package edu.iastate.cs228.hw1;

import java.net.SocketOption;
import java.util.stream.Stream;

public class Casual extends TownCell {
	public Casual(Town p, int r, int c) {
		super(p, r, c);
	}

	// Returns the State type of cell
	@Override
	public State who() {
		return State.CASUAL;
	}

	/**
	 * Determines the cell type in the next billing cycle based on the neighborhood
	 * census. The method calculates the neighborhood census and chooses the next
	 * cell type accordingly.
	 *
	 * @param tNew The Town object for the next billing cycle.
	 * @return A new TownCell object representing the cell's state in the next
	 *         cycle.
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];

		// Calculate the census of the neighborhood cells
		census(nCensus);

		if (nCensus[OUTAGE] + nCensus[EMPTY] <= 1) {
			return new Reseller(tNew, row, col);
		} else if (nCensus[RESELLER] > 0) {
			return new Outage(tNew, row, col);
		} else if (nCensus[STREAMER] > 0 || nCensus[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		} else {
			return new Casual(tNew, row, col);
		}
	}
}
