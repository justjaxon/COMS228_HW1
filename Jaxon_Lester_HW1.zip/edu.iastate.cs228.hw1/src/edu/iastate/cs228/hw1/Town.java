package edu.iastate.cs228.hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 * @author Jaxon Lester
 *
 */
public class Town {

	private int length, width; // Row and column (first and second indices)
	public TownCell[][] grid;

	/**
	 * Constructor for initializing a Town object with a specified width and length.
	 * This constructor creates a 2D grid but does not populate individual cells.
	 *
	 * @param width  The number of columns in the grid.
	 * @param length The number of rows in the grid.
	 */
	public Town(int width, int length) {

		// Creating variables using @param length and @param width
		this.length = width;
		this.width = length;

		// creating a new TownCell using @Param
		grid = new TownCell[width][length];

	}

	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of
	 * catching it. Ensure that you close any resources (like file or scanner) which
	 * is opened in this function.
	 * 
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	/**
	 * Constructor for initializing a Town object based on data from a file.
	 *
	 * @param inputFileName The name of the input file containing grid data.
	 * @throws FileNotFoundException If the specified input file is not found.
	 */
	public Town(String inputFileName) throws FileNotFoundException {
		// Create a new File object using the provided inputFileName
		File file = new File(inputFileName);

		try {
			// Create a scanner to read from the input file
			Scanner scan = new Scanner(file);

			// Read the width and length from the file
			this.width = scan.nextInt();
			this.length = scan.nextInt();

			// Initialize the grid based on the dimensions
			grid = new TownCell[width][length];

			// Populate the grid based on file data
			while (scan.hasNextLine()) {
				for (int x = 0; x < width; x++) {
					for (int y = 0; y < length; y++) {
						switch (scan.next()) {
						case "C":
							grid[x][y] = new Casual(this, x, y);
							break;
						case "S":
							grid[x][y] = new Streamer(this, x, y);
							break;
						case "R":
							grid[x][y] = new Reseller(this, x, y);
							break;
						case "E":
							grid[x][y] = new Empty(this, x, y);
							break;
						case "O":
							grid[x][y] = new Outage(this, x, y);
							break;
						}
					}
				}
			}

			// Close the scanner to release resources
			scan.close();

		} catch (FileNotFoundException e) {
			// The constructor throws a FileNotFoundException if the specified file is not
			// found.
			throw new FileNotFoundException("The specified input file '" + inputFileName + "' was not found.");
		}
	}

	/**
	 * Returns width of the grid.
	 * 
	 * @return
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Returns length of the grid.
	 * 
	 * @return
	 */
	public int getLength() {
		return length;
	}

	/**
	 * Randomly initializes the grid cells of the Town object based on a given seed.
	 * Each cell in the grid is assigned a random state.
	 *
	 * @param seed The seed for the random number generator.
	 */
	public void randomInit(int seed) {
		Random rand = new Random(seed);

		// Iterate over the grid and assign random states to each cell
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < length; y++) {
				int randVal = rand.nextInt(5);
				switch (randVal) {
				case TownCell.CASUAL:
					grid[x][y] = new Casual(this, x, y);
					break;
				case TownCell.STREAMER:
					grid[x][y] = new Streamer(this, x, y);
					break;
				case TownCell.RESELLER:
					grid[x][y] = new Reseller(this, x, y);
					break;
				case TownCell.EMPTY:
					grid[x][y] = new Empty(this, x, y);
					break;
				case TownCell.OUTAGE:
					grid[x][y] = new Outage(this, x, y);
					break;
				}
			}
		}
	}

	/**
	 * Returns a string representation of the town grid. Each square is represented
	 * by the first letter of the cell type, separated by a single space or a tab.
	 * Each row is separated by a newline character.
	 *
	 * @return A string representation of the town grid.
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();

		// Iterate over the grid and append the first letter of each cell type to the
		// string
		for (int x = 0; x < width; x++) {
			for (int y = 0; y < length; y++) {
				sb.append(grid[x][y].who().toString().charAt(0)).append(" ");
			}
			sb.append("\n");
		}

		return sb.toString();
	}
}