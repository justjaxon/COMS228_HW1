package edu.iastate.cs228.hw1;

/**
 * Represents a streamer cell in the town grid.
 */
public class Streamer extends TownCell {

	/**
	 * Constructs a Streamer object with references to the town, row, and column.
	 *
	 * @param p The town this cell belongs to.
	 * @param r The row index of this cell.
	 * @param c The column index of this cell.
	 */
	public Streamer(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the State type of the cell, which is STREAMER.
	 *
	 * @return State.STREAMER
	 */
	@Override
	public State who() {
		return State.STREAMER;
	}

	/**
	 * Determines the cell type in the next billing cycle based on the neighborhood
	 * census. The method calculates the neighborhood census and chooses the next
	 * cell type accordingly.
	 *
	 * @param tNew The Town object for the next billing cycle.
	 * @return A new TownCell object representing the cell's state in the next
	 * cycle.
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];

		census(nCensus);

		if (nCensus[OUTAGE] + nCensus[EMPTY] <= 1) {
			return new Reseller(tNew, row, col);
		} else if (nCensus[RESELLER] > 0) {
			return new Outage(tNew, row, col);
		} else if (nCensus[OUTAGE] > 0) {
			return new Empty(tNew, row, col);
		}

		return new Streamer(tNew, row, col);
	}
}
