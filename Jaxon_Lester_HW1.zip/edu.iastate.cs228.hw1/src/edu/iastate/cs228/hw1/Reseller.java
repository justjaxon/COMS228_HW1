package edu.iastate.cs228.hw1;

/**
 * Represents a reseller cell in the town grid.
 */
public class Reseller extends TownCell {

	/**
	 * Constructs a Reseller object with references to the town, row, and column.
	 *
	 * @param p The town this cell belongs to.
	 * @param r The row index of this cell.
	 * @param c The column index of this cell.
	 */
	public Reseller(Town p, int r, int c) {
		super(p, r, c);
	}

	/**
	 * Returns the State type of the cell, which is RESELLER.
	 *
	 * @return State.RESELLER
	 */
	@Override
	public State who() {
		return State.RESELLER;
	}

	/**
	 * Determines the cell type in the next billing cycle based on the neighborhood
	 * census. The method calculates the neighborhood census and chooses the next
	 * cell type accordingly.
	 *
	 * @param tNew The Town object for the next billing cycle.
	 * @return A new TownCell object representing the cell's state in the next
	 *         cycle.
	 */
	@Override
	public TownCell next(Town tNew) {
		int[] nCensus = new int[5];

		census(nCensus);

		if (nCensus[CASUAL] <= 3 || nCensus[EMPTY] >= 3) {
			return new Empty(tNew, row, col);
		}
		if (nCensus[CASUAL] >= 5) {
			return new Streamer(tNew, row, col);
		} else {
			return new Reseller(tNew, row, col);
		}
	}
}
