package edu.iastate.cs228.hw1;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Random;

/**
 * @author Jaxon Lester
 *
 * The ISPBusiness class performs simulation over a grid 
 * plain with cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {
	
	/**
	 * Generates a new Town object representing the updated grid for the next billing cycle
	 * based on the provided current Town object.
	 *
	 * @param tOld The old/current Town object.
	 * @return A new Town object representing the updated grid for the next billing cycle.
	 */
	public static Town updatePlain(Town tOld) {
	    int length = tOld.getLength();
	    int width = tOld.getWidth();
	    Town tNew = new Town(length, width);

	    // Iterate through the old town grid and update it in the new town
	    for (int x = 0; x < width; x++) {
	        for (int y = 0; y < length; y++) {
	            tNew.grid[x][y] = tOld.grid[x][y].next(tNew);
	        }
	    }
	    
	    return tNew;
	}
	
	/**
	 * Calculates and returns the profit for the current state in the town grid
	 * based on the number of CASUAL customers.
	 *
	 * @param town The Town object representing the current state of the grid.
	 * @return The profit generated from CASUAL customers.
	 */
	public static int getProfit(Town town) {
	    int casualCount = 0;

	    // Iterate through the town grid and count the number of CASUAL customers
	    for (int x = 0; x < town.getWidth(); x++) {
	        for (int y = 0; y < town.getLength(); y++) {
	            if (town.grid[x][y].who() == State.CASUAL) {
	                casualCount++;
	            }
	        }
	    }

	    return casualCount;
	}
	

	/**
	 *  Main method. Interact with the user and ask if user wants to specify elements of grid
	 *  via an input file (option: 1) or wants to generate it randomly (option: 2).
	 *  
	 *  Depending on the user choice, create the Town object using respective constructor and
	 *  if user choice is to populate it randomly, then populate the grid here.
	 *  
	 *  Finally: For 12 billing cycle calculate the profit and update town object (for each cycle).
	 *  Print the final profit in terms of %. You should print the profit percentage
	 *  with two digits after the decimal point:  Example if profit is 35.5600004, your output
	 *  should be:
	 *
	 *	35.56%
	 *  
	 * Note that this method does not throw any exception, so you need to handle all the exceptions
	 * in it.
	 * 
	 * @param args
	 * 
	 */
    public static void main(String[] args) {
        int userInput;
        final int billingCycle = 12;

        Scanner scanner = new Scanner(System.in);

        try {
            System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed");
            userInput = scanner.nextInt();
            Town town = null;

            if (userInput == 1) {
                String filePath;

                System.out.println("Please Enter The File Name or Path!");
                scanner.nextLine(); // Consume newline character
                filePath = scanner.nextLine();

                File file = new File(filePath);
                town = new Town(filePath);
            } else if (userInput == 2) {
                int seed, row, col;

                System.out.println("Enter Rows, Cols, and the SEED! separated by a space");
                row = scanner.nextInt();
                col = scanner.nextInt();
                seed = scanner.nextInt();
                town = new Town(row, col);

                town.randomInit(seed);
            }

            double totalProfit = 0.0;

            for (int month = 0; month < billingCycle; month++) {
                double profitPercentage = (getProfit(town) / ((double) town.getWidth() * (double) town.getLength())) * 100;
                totalProfit += profitPercentage;
                town = updatePlain(town);
            }

            double averageProfit = totalProfit / billingCycle;
            System.out.printf("%.2f%%", averageProfit);

        } catch (FileNotFoundException e) {
            System.out.println("Invalid file path: " + e.toString());
        } finally {
            scanner.close();
        }
    }
}