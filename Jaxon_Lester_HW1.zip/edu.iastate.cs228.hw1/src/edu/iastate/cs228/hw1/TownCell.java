package edu.iastate.cs228.hw1;

/**
 * Abstract base class for representing cells in a town grid.
 * Each cell has a reference to the town it belongs to, as well as
 * its position represented by row and column indices.
 * Subclasses must implement methods to identify their state and determine
 * their state in the next cycle.
 *
 * @author Jaxon Lester
 */
public abstract class TownCell {

    protected Town plain;
    protected int row;
    protected int col;

    // Constants to be used as indices for cell types
    protected static final int RESELLER = 0;
    protected static final int EMPTY = 1;
    protected static final int CASUAL = 2;
    protected static final int OUTAGE = 3;
    protected static final int STREAMER = 4;

    public static final int NUM_CELL_TYPE = 5;

    // Use this static array to take a census of cell types.
    public static final int[] nCensus = new int[NUM_CELL_TYPE];

    /**
     * Constructor for creating a TownCell object with a reference to the town,
     * and row and column indices.
     *
     * @param p   The town this cell belongs to.
     * @param r   The row index of this cell.
     * @param c   The column index of this cell.
     */
    public TownCell(Town p, int r, int c) {
        plain = p;
        row = r;
        col = c;
    }

    /**
     * Takes a census of the neighborhood cell types.
     * Counts the number of each cell type in the neighborhood.
     *
     * @param nCensus An array to store the census count of each cell type.
     */
    public void census(int nCensus[]) {
        // Initialize the counts of all cell types to zero
        for (int i = 0; i < NUM_CELL_TYPE; i++) {
            nCensus[i] = 0;
        }

        // Iterate over the neighborhood cells and update the census counts
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                // Exclude the center cell and cells outside the grid boundaries
                if ((i != row || j != col) && i >= 0 && i < plain.getLength() && j >= 0 && j < plain.getWidth()) {
                    switch (plain.grid[i][j].who()) {
                        case CASUAL:
                            nCensus[CASUAL]++;
                            break;
                        case RESELLER:
                            nCensus[RESELLER]++;
                            break;
                        case EMPTY:
                            nCensus[EMPTY]++;
                            break;
                        case OUTAGE:
                            nCensus[OUTAGE]++;
                            break;
                        case STREAMER:
                            nCensus[STREAMER]++;
                            break;
                    }
                }
            }
        }
    }

    /**
     * Gets the identity of the cell.
     *
     * @return The state of the cell.
     */
    public abstract State who();

    /**
     * Determines the cell type in the next cycle.
     *
     * @param tNew The town of the next cycle.
     * @return A new TownCell object representing the cell's state in the next cycle.
     */
    public abstract TownCell next(Town tNew);
}